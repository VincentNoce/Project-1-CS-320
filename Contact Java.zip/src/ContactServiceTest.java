import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {
    private ContactService contactService;

    @BeforeEach
    public void setUp() {
        contactService = new ContactService();
    }

    @Test
    public void testAddContact() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");

        contactService.addContact(contact);
        assertTrue(contactService.getContacts().containsKey("12345"));
    }

    @Test
    public void testAddContactWithDuplicateId() {
        Contact contact1 = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact1);
        
        Contact contact2 = new Contact("12345", "Jane", "Smith", "9876543210", "456 Oak St");
        assertThrows(IllegalArgumentException.class, () -> contactService.addContact(contact2));
    }

    @Test
    public void testUpdateContactFirstName() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);

        assertTrue(contactService.updateContactFirstName("12345", "Jane"));
        assertEquals("Jane", contactService.getContacts().get("12345").getFirstName());
    }
}
