import java.util.HashMap;
import java.util.Map;

public class ContactService {
    private final Map<String, Contact> contacts;

    public ContactService() {
        contacts = new HashMap<>();
    }

    public void addContact(Contact contact) {
        if (contacts.containsKey(contact.getContactId())) {
            throw new IllegalArgumentException("Duplicate contact ID");
        }
        contacts.put(contact.getContactId(), contact);
    }

    public void deleteContact(String contactId) {
        contacts.remove(contactId);
    }

    public boolean updateContactFirstName(String contactId, String firstName) {
        Contact existingContact = contacts.get(contactId);
        if (existingContact != null) {
            existingContact.setFirstName(firstName);
            return true;
        }
        return false;
    }

    public Map<String, Contact> getContacts() {
        return contacts;
    }
}
