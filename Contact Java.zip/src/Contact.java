public class Contact {
    private String contactId;
    private String firstName;
    private String lastName;
    private String phone;
    private String address;

    public Contact(String contactId, String firstName, String lastName, String phone, String address) {
        this.contactId = validateId(contactId);
        this.firstName = validateString(firstName, "First Name", 10);
        this.lastName = validateString(lastName, "Last Name", 10);
        this.phone = validatePhone(phone);
        this.address = validateString(address, "Address", 30);
    }

    public String getContactId() {
        return contactId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = validateString(firstName, "First Name", 10);
    }

    public String getLastName() {
        return lastName;
    }

    public String getPhone() {
        return phone;
    }

    public String getAddress() {
        return address;
    }

    private String validateId(String id) {
        if (id != null && id.length() <= 10) {
            return id;
        } else {
            throw new IllegalArgumentException("Contact ID must not be null and must not exceed 10 characters");
        }
    }

    private String validateString(String value, String fieldName, int maxLength) {
        if (value != null && value.length() <= maxLength) {
            return value;
        } else {
            throw new IllegalArgumentException(fieldName + " must not be null and must not exceed " + maxLength + " characters");
        }
    }

    private String validatePhone(String phone) {
        if (phone != null && phone.matches("\\d{10}")) {
            return phone;
        } else {
            throw new IllegalArgumentException("Phone must not be null and must be exactly 10 digits");
        }
    }
}
